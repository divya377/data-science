# --------------------------------------------------------
# SALES DATA ANALYSIS DASHBOARD - FULL PROJECT CODE
# --------------------------------------------------------

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# --------------------------------------------------------
# 1. Load Dataset
# --------------------------------------------------------
df = pd.read_csv("sales_dataset.csv")   # Make sure file is in same folder
print("Dataset Loaded Successfully!")

print("\nFIRST 5 ROWS:")
print(df.head())


# --------------------------------------------------------
# 2. Handle Missing Data
# --------------------------------------------------------
print("\nMissing Values Before Cleaning:")
print(df.isnull().sum())

df['Quantity'] = df['Quantity'].fillna(df['Quantity'].median())
df['Region'] = df['Region'].fillna(df['Region'].mode()[0])
df['Product'] = df['Product'].fillna(df['Product'].mode()[0])

print("\nMissing Values After Cleaning:")
print(df.isnull().sum())


# --------------------------------------------------------
# 3. Convert Date column
# --------------------------------------------------------
df['Date'] = pd.to_datetime(df['Date'])
df['Month'] = df['Date'].dt.to_period('M')


# --------------------------------------------------------
# 4. Insights and Grouping
# --------------------------------------------------------

# Monthly Sales Trend
monthly_sales = df.groupby('Month')['Total Sales'].sum()

# Best-selling products
best_products = df.groupby('Product')['Total Sales'].sum().sort_values(ascending=False)

# Sales by region
region_sales = df.groupby('Region')['Total Sales'].sum()

# Category-wise sales
category_sales = df.groupby('Category')['Total Sales'].sum()


# --------------------------------------------------------
# 5. Visualizations
# --------------------------------------------------------

sns.set(style="whitegrid")

# 1️⃣ Monthly Sales Trend
plt.figure(figsize=(10,5))
sns.lineplot(x=monthly_sales.index.astype(str), y=monthly_sales.values)
plt.title("Monthly Sales Trend", fontsize=14)
plt.xlabel("Month")
plt.ylabel("Total Sales")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


# 2️⃣ Top 10 Best-Selling Products
plt.figure(figsize=(10,5))
best_products.head(10).plot(kind='bar', color='skyblue')
plt.title("Top 10 Best-Selling Products", fontsize=14)
plt.ylabel("Total Sales")
plt.tight_layout()
plt.show()


# 3️⃣ Sales by Region (Pie Chart)
plt.figure(figsize=(7,7))
region_sales.plot(kind='pie', autopct='%1.1f%%')
plt.title("Sales Distribution by Region", fontsize=14)
plt.ylabel("")  
plt.show()


# 4️⃣ Category-wise Sales
plt.figure(figsize=(10,5))
category_sales.plot(kind='bar', color='orange')
plt.title("Category-wise Sales", fontsize=14)
plt.ylabel("Total Sales")
plt.tight_layout()
plt.show()


# 5️⃣ Price vs Quantity Relationship
plt.figure(figsize=(10,5))
sns.scatterplot(data=df, x='Unit Price', y='Quantity')
plt.title("Relationship Between Unit Price and Quantity Sold", fontsize=14)
plt.tight_layout()
plt.show()


# --------------------------------------------------------
# 6. Summary Insights Printed
# --------------------------------------------------------

print("\n------------ KEY INSIGHTS -----------------")

print("\n📌 Highest Selling Product:")
print(best_products.idxmax(), " - Rs.", best_products.max())

print("\n📌 Region with Highest Sales:")
print(region_sales.idxmax(), " - Rs.", region_sales.max())

print("\n📌 Best Month for Sales:")
print(monthly_sales.idxmax(), " - Rs.", monthly_sales.max())

print("\n📌 Category with Highest Sales:")
print(category_sales.idxmax(), " - Rs.", category_sales.max())

print("\n------------ END OF DASHBOARD -----------------")
